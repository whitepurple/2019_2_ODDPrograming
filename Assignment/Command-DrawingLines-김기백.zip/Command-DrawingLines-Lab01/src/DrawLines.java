import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
/**
 * @copyright 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습
 * @version 2019년도 2학기 
 * @author 김상진
 * @file DrawLines.java: JavaFX 메인 프로그램
 * 수평(가로, horizontal), 수직(세로, vertical) 선 그리기 
 */
public class DrawLines extends Application {
private LinePane linePane = new LinePane();
	
	private Pane constructButtonPane() {
		Button horizontalDrawButton = new Button("Horizontal");
		Button verticalDrawButton = new Button("Vertical");
		Button undoButton = new Button("Undo");
		Button redoButton = new Button("Redo");
		
		HBox buttonPane = new HBox();
		buttonPane.setPadding(new Insets(10));
		buttonPane.setSpacing(10);
		buttonPane.setAlignment(Pos.CENTER);		
		horizontalDrawButton.setMinWidth(100);
		verticalDrawButton.setMinWidth(100);
		undoButton.setMinWidth(100);
		redoButton.setMinWidth(100);
		buttonPane.getChildren().addAll(
			horizontalDrawButton, verticalDrawButton, undoButton, redoButton);

		horizontalDrawButton.setOnAction(e->{linePane.drawHorizontalLine();});
		verticalDrawButton.setOnAction(e->{linePane.drawVerticalLine();});
		undoButton.setOnAction(e->{linePane.undo();});
		redoButton.setOnAction(e->{linePane.redo();});
		
		return buttonPane;
	}
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		BorderPane mainPane = new BorderPane();
				
		linePane.setPrefWidth(500);
		linePane.setPrefHeight(500);
		mainPane.setCenter(linePane);
		mainPane.setBottom(constructButtonPane());
		
		primaryStage.setTitle("Command Pattern: DrawLines");
		primaryStage.setScene(new Scene(mainPane));
		primaryStage.setResizable(false);
		primaryStage.show();
	}

	public static void main(String[] args) {
		Application.launch(args);
	}
}
