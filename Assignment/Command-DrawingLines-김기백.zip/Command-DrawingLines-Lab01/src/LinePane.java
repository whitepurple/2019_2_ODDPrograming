import java.util.Stack;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;

/**
 * @copyright 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습
 * @version 2019년도 2학기
 * @author 김상진
 * @file LinePane.java: 선을 그리는 Pane 
 * 선을 그리면 그린 선을 undoStack에 추가, redoStack은 clear
 * undo가 실행되면 undoStack에 있는 선을 삭제, redoStack에 선을 추가
 */
public class LinePane extends Pane {
	private int x = 10;
	private int y = 10;
	private Stack<Line> undoStack = new Stack<>();
	private Stack<Line> redoStack = new Stack<>();
	
	public void drawHorizontalLine() {
		Line line = new Line(0, y, getWidth(), y);
		line.setStroke(Color.BLUE);
		getChildren().add(line);
		y += 10;
		undoStack.push(line);
		redoStack.clear();
	}
	public void drawVerticalLine() {
		Line line = new Line(x, 0, x, getHeight());
		line.setStroke(Color.RED);
		getChildren().add(line);
		x += 10; 
		undoStack.push(line);
		redoStack.clear();
	}
	public void undo() {
		if(!undoStack.isEmpty()) {
			Line line = undoStack.pop();
			redoStack.push(line);
			if(line.getStartX()>0.0)
				x -= 10;
			else
				y -= 10;
			getChildren().remove(line);
		}
	}
	public void redo() {
		if(!redoStack.isEmpty()) {
			Line line = redoStack.pop();
			if(line.getStartX()>0.0)
				x += 10;
			else
				y += 10;
			undoStack.push(line);
			getChildren().add(line);
		}
	}
}
