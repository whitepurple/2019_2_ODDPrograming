import java.util.Stack;
import javafx.scene.layout.Pane;

/**
 * @copyright 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습
 * @version 2019년도 2학기
 * @author 김상진
 * @file LinePane.java: 선을 그리는 Pane 
 * 선을 그리면 그린 선을 undoStack에 추가, redoStack은 clear
 * undo가 실행되면 undoStack에 있는 선을 삭제, redoStack에 선을 추가
 */
public class LinePane extends Pane {
	private Stack<Command> undoStack = new Stack<>();
	private Stack<Command> redoStack = new Stack<>();
	
	public void drawLine(Command command) {
		command.execute();
		redoStack.clear();
		undoStack.push(command);
	}
	public void undo() {
		if(!undoStack.isEmpty()) {
			Command command = undoStack.pop();
			redoStack.push(command);
			command.undo();
		}
	}
	public void redo() {
		if(!redoStack.isEmpty()) {
			Command command = redoStack.pop();
			undoStack.push(command);
			command.execute();
		}
	}
}
