import java.util.Stack;

public class CommandManager {
	private Stack<Command> undoStack = new Stack<>();
	private Stack<Command> redoStack = new Stack<>();
	public void execute(Command... commands){
		for(var command:commands) {
			undoStack.push(command);
			command.execute();
		}
		redoStack.clear();
	}
	public void undo() {
		if(!undoStack.isEmpty()) {
			Command command = undoStack.pop();
			redoStack.push(command);
			command.undo();
		}
	}
	public void redo() {
		if(!redoStack.isEmpty()) {
			Command command = redoStack.pop();
			undoStack.push(command);
			command.execute();
		}
	}
}
