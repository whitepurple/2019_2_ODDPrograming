import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * @copyright 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습
 * @version 2019년도 2학기
 * @author 김상진
 * @file DrawLines 
 * 선을 그리면 Command 객체를 undoStack에 추가, redoStack은 clear
 * undo가 실행되면 undoStack에는 명령 객체의 undo 실행, redoStack에 명령 객체를 추가
 */
public class DrawLines extends Application {
	private Pane linePane = new Pane();
	private CommandManager commandManager = new CommandManager();

	private Pane constructButtonPane() {
		Button horizontalDrawButton = new Button("Horizontal");
		Button verticalDrawButton = new Button("Vertical");
		Button undoButton = new Button("Undo");
		Button redoButton = new Button("Redo");
		
		HBox buttonPane = new HBox();
		buttonPane.setPadding(new Insets(10));
		buttonPane.setSpacing(10);
		buttonPane.setAlignment(Pos.CENTER);		
		horizontalDrawButton.setMinWidth(100);
		verticalDrawButton.setMinWidth(100);
		undoButton.setMinWidth(100);
		redoButton.setMinWidth(100);
		buttonPane.getChildren().addAll(
			horizontalDrawButton, verticalDrawButton, undoButton, redoButton);

		horizontalDrawButton.setOnAction(e->{
			commandManager.execute(new HorizontalLineDrawCommand(linePane));
		});
		verticalDrawButton.setOnAction(e->{
			commandManager.execute(new VerticalLineDrawCommand(linePane));
		});
		undoButton.setOnAction(e->{
			commandManager.undo();
		});
		redoButton.setOnAction(e->{
			commandManager.redo();
		});
		
		return buttonPane;
	}	
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		BorderPane mainPane = new BorderPane();
		
		linePane.setPrefWidth(500);
		linePane.setPrefHeight(500);
		mainPane.setCenter(linePane);
		mainPane.setBottom(constructButtonPane());
		
		primaryStage.setTitle("Command Pattern: DrawLines");
		primaryStage.setScene(new Scene(mainPane));
		primaryStage.setResizable(false);
		primaryStage.show();
	}

	public static void main(String[] args) {
		Application.launch(args);
	}

}
