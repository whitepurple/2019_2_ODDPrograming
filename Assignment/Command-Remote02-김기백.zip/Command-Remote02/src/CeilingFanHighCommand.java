
public class CeilingFanHighCommand implements Command {
	private CeilingFan ceilingFan;
	
	public CeilingFanHighCommand(CeilingFan ceilingFan) {
		this.ceilingFan = ceilingFan;
	}
	@Override
	public void execute() {
		ceilingFan.setSpeed(CeilingFan.SPEED
				.values()[(ceilingFan.getSpeed().ordinal()+1)%4]);
	}

	@Override
	public void undo() {
		ceilingFan.setSpeed(CeilingFan.SPEED
				.values()[(ceilingFan.getSpeed().ordinal()-1)%4]);
	}

}
