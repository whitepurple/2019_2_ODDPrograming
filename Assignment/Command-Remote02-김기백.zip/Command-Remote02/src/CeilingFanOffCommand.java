
public class CeilingFanOffCommand implements Command {
	private CeilingFan ceilingFan;
	private CeilingFan.SPEED prevSpeed;
	public CeilingFanOffCommand(CeilingFan ceilingFan) {
		this.ceilingFan = ceilingFan;
	}
	@Override
	public void execute() {
		prevSpeed = ceilingFan.getSpeed();
		ceilingFan.setSpeed(CeilingFan.SPEED.OFF);
	}

	@Override
	public void undo() {
		ceilingFan.setSpeed(prevSpeed);
	}

}
