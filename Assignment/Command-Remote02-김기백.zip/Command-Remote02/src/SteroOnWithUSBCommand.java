
public class SteroOnWithUSBCommand implements Command {
	private Stero stero;
	public SteroOnWithUSBCommand(Stero stero){
		this.stero = stero;
	}
	@Override
	public void execute() {
		stero.on();	
		stero.setInput(Stero.InputType.USB);
		stero.setVolume(11);
	}
	@Override
	public void undo() {
		stero.off();
	}
}