import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

/**
 * 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습 
 * @version 2019년도 2학기
 * @author 김상진
 * @file Beverage.java
 * 장식패턴에서 장식대상 추상클래스
 * 기본 예제
 */
public abstract class Beverage {
	private String description = "이름없는 음료";
	public void setDescription(String description){
		this.description = description;
	}
	public String getDescription(){
		return description;
	}
	public abstract int cost();
	protected Beverage() {}
	public Beverage removeCondiment() {return this;}
	public static Beverage createCoffee(String coffee, String... list)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, IllegalArgumentException, 
					InvocationTargetException, NoSuchMethodException, SecurityException {
		Class<? extends Beverage> coffeeClass
			= Class.forName(coffee).asSubclass(Beverage.class);
		
		if(coffeeClass.getSuperclass()!=Beverage.class||coffeeClass==CondimentDecorator.class)
			throw new IllegalArgumentException("Must use Concrete Decoretee");
		
		Constructor<? extends Beverage> coffeeConstructor = coffeeClass.getDeclaredConstructor();
		Beverage beverage = (Beverage)coffeeConstructor.newInstance();
		
		for(String s: list) {
			//규칙 테스트에 만족하면 장식
			if(CoffeeRuleTest.getRule().ruleTest(s, beverage.getDescription())) {
				//s 의 이름을 가진 클래스와 생성자를 불러와서 커피를 장식하는 코드 
				Class<? extends CondimentDecorator> condimentClass
					= Class.forName(s).asSubclass (CondimentDecorator.class);
				Constructor<? extends CondimentDecorator> condimentConstructor 
					= condimentClass.getDeclaredConstructor(Beverage.class);
				beverage = (Beverage)condimentConstructor.newInstance(beverage);
				//
			}
		}
		return beverage;
	};
	public boolean equals(Beverage beverage) {
		return extractClass(beverage).equals(extractClass(this));
	}
	protected String extractClass(Beverage beverage) {
		if(beverage.getClass().getSuperclass() == Beverage.class)
			return beverage.getClass().getName();
		return (beverage.getClass().getName() + "/" +extractClass(beverage.removeCondiment()));
	}
}
