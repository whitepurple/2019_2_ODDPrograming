
//전략 패턴을 사용한 커피 규칙을 위한 인터페이스
public interface CoffeeRule {
	//description에서 문자열을 세기 위한 함수
	default int countCondiment(String s, String b) {
		String[] list = b.split(", ");
		int count = 0;
		for(String i : list) {
			if(s.equals(i)) count++;
		}
		return count;
	}
	boolean RuleTest(String beverage);
}
