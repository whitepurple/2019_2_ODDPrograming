import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

//싱글톤에 전략패턴 적용
public class CoffeeRuleTest {
	private static CoffeeRuleTest uniqueInstance = null;
	private CoffeeRuleTest() {}
	public static CoffeeRuleTest getRule() {
		if(uniqueInstance==null) uniqueInstance = new CoffeeRuleTest();
		return uniqueInstance;
	}
	public boolean ruleTest(String s, String b) 
			throws ClassNotFoundException, NoSuchMethodException, SecurityException, InstantiationException, 
				IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		
		Class<?> rule = Class.forName(s+"Rule");
		Constructor<?> ruleConstructor = rule.getConstructor();
		CoffeeRule coffeeRule = (CoffeeRule)ruleConstructor.newInstance();
		
		boolean result = coffeeRule.RuleTest(b);
		return result;
	}
}
