import java.util.ArrayList;

/**
 * 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습 
 * @version 2019년도 2학기
 * @author 김상진
 * @file CoffeeTest.java
 * 테스트 프로그램
 */
public class CoffeeTest {
	public static void main(String[] args) {
		/*Beverage beverage = new HouseBlend();
		beverage = new Mocha(beverage);
		beverage = new Whip(beverage);
		beverage = new Mocha(beverage);
		System.out.printf("%s: %,d원%n", 
			beverage.getDescription(), beverage.cost());
		
		beverage = new DarkRoast();
		beverage = new Mocha(beverage);
		beverage = beverage.removeCondiment();
		beverage = new Milk(beverage);
		System.out.printf("%s: %,d원%n", 
			beverage.getDescription(), beverage.cost());
	*/
		try {
			ArrayList<Beverage> Coffee = new ArrayList<Beverage>();
			//coffee_1// 우유는 한 번만 추가할 수 있다.
			Coffee.add(Beverage.createCoffee("DarkRoast", "Milk", "Milk", "Milk", "Mocha", "Whip"));
			
			//coffee_2// 더블모카 ok, 트리플모카 no
			//coffee_2, coffee_3// 장식자의 순서가 달라도 같은 커피로 비교할 수 있다.
			Coffee.add(Beverage.createCoffee("HouseBlend", "Mocha", "Whip", "Milk", "Mocha", "Mocha"));
			Coffee.add(Beverage.createCoffee("HouseBlend", "Whip", "Mocha", "Mocha", "Milk"));

			//coffee_4, coffee_5// 장식이 안된 커피끼리도 비교할 수 있다.
			//coffee_5// 에스프레소에는 크림 장식이 안된다.
			Coffee.add(Beverage.createCoffee("Espresso"));
			Coffee.add(Beverage.createCoffee("Espresso", "Whip"));
			
			Coffee.stream().forEach(coffee -> System.out.printf("coffee_%d) %s: %,d원%n",
												Coffee.indexOf(coffee)+1, coffee.getDescription(), coffee.cost()));
			
			System.out.println(Coffee.get(1).equals(Coffee.get(2)));
			System.out.println(Coffee.get(3).equals(Coffee.get(4)));
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}
