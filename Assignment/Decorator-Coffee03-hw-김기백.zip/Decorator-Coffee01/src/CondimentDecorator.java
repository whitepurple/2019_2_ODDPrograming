import java.util.ArrayList;
import java.util.Arrays;

/**
 * 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습 
 * @version 2019년도 2학기
 * @author 김상진
 * @file CondimentDecorator.java
 * 장식패턴에서 장식자 추상 클래스
 */
public abstract class CondimentDecorator extends Beverage {
	private Beverage beverage;
	protected void setDecoratee(Beverage beverage) {
		this.beverage = beverage;
	}
	protected Beverage getBeverage() {
		return beverage;
	}
	public CondimentDecorator (Beverage beverage) {
		this.beverage = beverage;
	}
	public abstract String getDescription();
	public Beverage removeCondiment() {
		return beverage;
	};
	@Override
	public boolean equals(Beverage beverage) {
		//장식된 클래스의 이름들을 불러와 정렬하여 비교
		ArrayList<String> coffee_1 = new ArrayList<> (Arrays.asList(extractClass(this).split("/")));
		ArrayList<String> coffee_2 = new ArrayList<> (Arrays.asList(extractClass(beverage).split("/")));
		coffee_1.sort(null);
		coffee_2.sort(null);
		return coffee_1.equals(coffee_2);
	}
}
