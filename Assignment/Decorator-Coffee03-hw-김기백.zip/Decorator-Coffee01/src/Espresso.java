
public class Espresso extends Beverage {
	public Espresso() {
		setDescription("에스프레소 커피");
	}
	@Override
	public int cost() {
		return 800;
	}

}
