
public class MilkRule implements CoffeeRule {

	@Override
	public boolean RuleTest(String beverage) {
		//우유는 한 번만 추가 가능
		if(countCondiment("우유", beverage)>0)
			return false;
		else 
			return true;
	}
	
}
