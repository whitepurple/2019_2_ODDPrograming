
public class MochaRule implements CoffeeRule {

	@Override
	public boolean RuleTest(String beverage) {
		//더블모카까지는 허옹, 트리플 모카는 불가
		if(countCondiment("모카", beverage)>1)
			return false;
		else
			return true;
	}

}
