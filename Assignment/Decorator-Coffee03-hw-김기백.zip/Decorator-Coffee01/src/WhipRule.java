
public class WhipRule implements CoffeeRule {

	@Override
	public boolean RuleTest(String beverage) {
		//에스프레소 커피에는 휩을 장식하지 않음
		if(countCondiment("에스프레소 커피", beverage)>0)
			return false;
		else
			return true;
	}

}
