import java.util.Iterator;

public class Test {

	public static void main(String[] args) {
		UnsortedArrayList<Integer> list = new UnsortedArrayList<>();
		list.pushBackAll(1,5,3,4,5,2);
		//for(var n: list) {
		//	System.out.println(n);
		//}
		Iterator<Integer> iterator = list.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
			

	}

}
