import java.util.Arrays;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;
/**
 * 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습
 * @version 2019년도 2학기
 * @author 김상진 
 * 배열 기반 비정렬 범용 리스트
 */
public class UnsortedArrayList<T> implements Iterable<T> {
	private int capacity = 5;
	private Object[] list = new Object[capacity];
	private int size = 0;
	
	private class ArrayListIterator implements ListIterator<T>{
		private int index = 0;
		private boolean addFlag = false;
		private boolean removeFlag = false;
		private boolean nextFlag = false;
		private boolean previousFlag = false;
		@Override
		public boolean hasNext() {
			return index<size;
		}
		@Override
		public T next() {
			removeFlag = addFlag = previousFlag = false;
			nextFlag = true;
			if(index>=size) throw new NoSuchElementException();
			T retval = elementData(index);
			++index;
			return retval;
		}
		@Override
		public boolean hasPrevious() {
			return index>0;
		}
		@Override
		public T previous() {
			removeFlag = addFlag = nextFlag = false;
			previousFlag = true;
			if(index<=0) throw new NoSuchElementException();
			T retval = elementData(index-1);
			--index;
			return retval;
		}
		@Override
		public int nextIndex() {
			return index;
		}
		@Override
		public int previousIndex() {
			return index-1;
		}
		@Override
		public void remove() {
			if(removeFlag||addFlag) throw new IllegalStateException();
			removeFlag = true;
			int removeIndex = (nextFlag)? index-1: index;
			for(int i=removeIndex; i<size-1; i++)
				list[i] = list[i+1];
			--size;
			if(nextFlag) --index;
		}
		@Override
		public void set(T e) {
			if(removeFlag||addFlag) throw new IllegalStateException();
			int setIndex = (nextFlag)? index-1: index;
			list[setIndex] = e;
		}
		@Override
		public void add(T e) {
			addFlag = true;
			if(size==capacity) {
				capacity *= 2;
				list = Arrays.copyOf(list, capacity);
			}
			for(int i=size-1; i>=index; i--)
				list[i+1] = list[i];
			list[index] = e;
			++size;
			++index;
		}
	}
	
	public boolean isFull(){
		return false;
	}
	public boolean isEmpty(){
		return size==0;
	}
	public int size() {
		return size;
	}
	@SuppressWarnings("unchecked")
    private T elementData(int index) {
        return (T)list[index];
    }
	public T peekBack() {
		if(isEmpty()) throw new IllegalStateException();
		return elementData(size-1);
	}
	public void pushBack(T item){
		if(size==capacity) {
			capacity *= 2;
			list = Arrays.copyOf(list, capacity);
		}
		list[size] = item;
		++size;
	}
	public T popBack() {
		if(isEmpty()) throw new IllegalStateException();
		T retval = elementData(size-1);
		--size;
		return retval;
	}
	public T get(int index){
		if(index>=0 && index<size) return elementData(index);
		else throw new IndexOutOfBoundsException("유효하지 않은 색인 사용");
	}
	public void remove(T item) {
		if(isEmpty()) return;
		for(int i=0; i<size; i++)
			if(elementData(i).equals(item)) {
				list[i] = list[size-1];
				--size;
				break;
			}
	}
	@SuppressWarnings("unchecked")
	public void pushBackAll(T... items) {
		for(var item: items) pushBack(item);
	}
	@Override
	public Iterator<T> iterator() {
		return new ArrayListIterator();
	}
	public ListIterator<T> listIterator() {
		return new ArrayListIterator();
	}
}
