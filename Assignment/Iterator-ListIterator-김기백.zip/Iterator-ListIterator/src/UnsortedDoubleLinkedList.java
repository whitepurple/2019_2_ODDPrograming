import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습
 * @version 2019년도 2학기
 * @author 김상진 
 * 단일 연결구조 기반 비정렬 범용 리스트
 */
public class UnsortedDoubleLinkedList<T> implements Iterable<T> {
	private static class Node<T>{
		private T item = null;
		private Node<T> prev = null;
		private Node<T> next = null;
	}
	private class LinkedListIterator implements ListIterator<T>{
		private Node<T> curr = head;
		private boolean addFlag = false;
		private boolean removeFlag = false;
		private boolean nextFlag = false;
		private boolean previousFlag = false;
		@Override
		public boolean hasNext() {
			return curr!=null;
		}
		@Override
		public T next() {
			removeFlag = addFlag = previousFlag = false;
			nextFlag = true;
			if(curr==null) throw new NoSuchElementException();
			Node<T> prev = curr;
			curr = curr.next;
			return prev.item;
		}
		@Override
		public boolean hasPrevious() {
			return curr.prev!=null;
		}
		@Override
		public T previous() {
			removeFlag = addFlag = nextFlag = false;
			previousFlag = true;
			if(curr==head) throw new NoSuchElementException();
			if(curr!=null)
				curr = curr.prev;
			else
				curr = tail;
			return curr.item;
		}
		@Override
		public int nextIndex() {
			Node<T> arrow = curr;
			if(arrow==null) throw new NoSuchElementException();
			int count = 0;
			while(arrow.prev!=null) {
				++count;
				arrow = arrow.prev;
			}
			return count;
		}
		@Override
		public int previousIndex() {
			if (curr==head) return -1;
			Node<T> arrow = (curr!=null)?curr.prev:tail;
			int count = 0;
			while(arrow.prev!=null) {
				++count;
				arrow = arrow.prev;
			}
			return count;
		}
		@Override
		public void remove() {
			if(removeFlag||addFlag) throw new IllegalStateException();
			removeFlag = true;
			Node<T> removeTarget = (curr!=null)?((nextFlag)? curr.prev:curr):tail;
			curr = removeTarget.next;
			if(removeTarget!=head)
				removeTarget.prev.next = removeTarget.next;
			else 
				curr = head = removeTarget.next;
			if(removeTarget!=tail) 
				removeTarget.next.prev = removeTarget.prev;
			else {
				curr = tail = removeTarget.prev;
			}
			removeTarget = null;
			System.gc();
			--size;
		}
		@Override
		public void set(T e) {
			if(removeFlag||addFlag) throw new IllegalStateException();
			Node<T> setTarget = (nextFlag)? curr.prev:curr;
			setTarget.item=e;
		}
		@Override
		public void add(T e) {
			addFlag = true;
			Node<T> newNode = new Node<>();
			newNode.item = e;
			Node<T> addTarget = (curr!=null)?curr.prev:tail;
			newNode.prev = addTarget;
			newNode.next = curr;
			addTarget.next = newNode;
			if(curr!=null) newNode.next.prev = newNode;
			++size;
		}
		
	}
	private Node<T> head = null;
	private Node<T> tail = null;
	private int size = 0;
	public boolean isFull() {
		return false;
	}
	public boolean isEmpty() {
		return size==0;
	}
	public int size() {
		return size;
	}
	public T get(int index) {
		if(index>=0&&index<size) {
			Node<T> curr = head;
			for(int i=0; i<index; i++) {
				curr = curr.next;
			}
			return curr.item;
		}
		else throw new IndexOutOfBoundsException();
	}
	public void pushFront(T item) {
		Node<T> newNode = new Node<>();
		newNode.item = item;
		newNode.next = head;
		if(head!=null) head.prev = newNode;
		else tail = newNode;
		head = newNode;
		++size;
	}
	public T popFront() {
		if(isEmpty()) throw new IllegalStateException();
		Node<T> popNode = head;
		head = head.next;
		if(head!=null) head.prev = null;
		else tail = null;
		--size;
		return popNode.item;
	}
	public T peekFront() {
		if(isEmpty()) throw new IllegalStateException();
		return head.item;
	}
	public void pushBack(T item) {
		Node<T> newNode = new Node<>();
		newNode.item = item;
		if(tail==null) head = tail = newNode;
		else{
			tail.next = newNode;
			newNode.prev = tail;
			tail = newNode;
		}
		++size;
	}
	public T popBack() {
		if(isEmpty()) throw new IllegalStateException();
		Node<T> popNode = tail;
		tail = tail.prev;
		if(tail!=null) tail.next = null;
		else head = null;
		--size;
		return popNode.item;
	}
	public T peekBack() {
		if(isEmpty()) throw new IllegalStateException();
		return tail.item;
	}
	@SuppressWarnings("unchecked")
	public void pushBackAll(T... items) {
		for(var item: items) pushBack(item);
	}
	public boolean find(T item) {
		if(isEmpty()) return false;
		Node<T> curr = head;
		while(curr!=null) {
			if(curr.item.equals(item)) return true;
			curr = curr.next;
		}
		return false;
	}
	public void removeFirst(T item) {
		if(isEmpty()) return;
		Node<T> dummy = new Node<>();
		dummy.next = head;
		head.prev = dummy;
		Node<T> curr = head;
		while(curr!=null) {
			if(curr.item.equals(item)) {
				curr.prev.next = curr.next;
				if(curr.next!=null) curr.next.prev = curr.prev;
				if(curr==tail) tail = tail.prev;
				--size;
				break;
			}
			else curr = curr.next;
		}
		head = dummy.next;
		if(head==null) tail = null;
		else head.prev = null;
	}
	@Override
	public Iterator<T> iterator() {
		return new LinkedListIterator();
	}
	public ListIterator<T> listIterator() {
		return new LinkedListIterator();
	}
}
