import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.IntStream;

/**
 * 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습
 * 2019년도 2학기 관찰자 패턴 실습
 * ChatRoom.java
 * 사용자 목록과 채팅 메시지 목록 유지
 * 채팅룸 목록, 사용자 목록 유지
 * @author 김상진
 *
 */
public class ChatRoom{
	private String roomName;
	private ChatRoomLog roomLog = new ChatRoomLog();
	// 관찰자 목록: Map<사용자ID, 마지막 받은 메시지 색인>
	private Map<String, Integer> userList = new HashMap<>();
	
	public ChatRoom(String name) {
		roomName = name;
	}
	
	public String getRoomName() {
		return roomName;
	}
	public ChatRoomLog getRoomLog() {
		return roomLog;
	}
	// 채팅 서버가 채팅방에 새 메시지가 생길 때마다 사용함
	public void newMessage(String userID, String message) {
		// 만약 여기에 예외 처리를 추가한다면...
		roomLog.addMessage(userID, message);
		updateUsers();
	}
	// 관찰자 추가
	// 사용자가 가입할 때 사용함
	// 사용자가 가입된 이후 발생한 메시지만 받음
	// userList Map에 사용자를 추가해야 함
	// @return 추가에 실패할 경우 false, 성공하면 true
	public boolean addUser(String userID) {
		userList.put(userID, roomLog.size()-1);
		return true;
	}
	// 관찰자 삭제
	public void deleteUser(String userID) {
		userList.remove(userID);
	}
	// 관찰자 패턴에서 notifyObservers에 해당
	// 채팅방에 있는 모든 사용자들에게 최신 메시지를 전달한다.
	// 이전에 받은 메시지부터 최신 메시지까지 전달해야 함. 
	// 즉, 사용자마다 전달해야 하는 메시지 수가 다를 수 있음
	// 특정 사용자는 현재 오프라인일 수 있음
	public void updateUsers() {
		ArrayList<ChatMessage> messages = roomLog.getMessages();
		/*
		for(var entry: userList.entrySet()) {
			User user = ChatServer.getServer().getUser(entry.getKey());
			if(user.isOnline()) {
				int lastMsg = entry.getValue()+1;
				while(true) {
					if(lastMsg >= roomLog.size()) break;
					String senderId;
					String message;
					ChatMessage msg = messages.get(lastMsg++);
					senderId = msg.getUserID();
					message = msg.getMessage();
					user.update(roomName, senderId, message);
				}
				userList.put(user.getUserID(),Integer.valueOf(lastMsg-1));
			}
		}*/
		userList.entrySet()
				.stream()
				.map(e -> ChatServer.getServer().getUser(e.getKey()) )
				.filter(u -> u.isOnline()) 
				.forEach(u -> {
								IntStream.range(userList.get(u.getUserID())+1,roomLog.size())
										 .forEachOrdered(i -> u.update(roomName, 
												 						messages.get(i).getUserID(),
																		messages.get(i).getMessage()));
								userList.put(u.getUserID(),roomLog.size()-1);
							  }
						);
	}
}
