/**
 * 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습
 * @version 2019년도 2학기 
 * 전략 패턴
 * ComputerPlayer.java: 전략을 활용하는 클라이언 클래스
 * @author 김상진
 */
public class ComputerPlayer extends Player {
	private PlayingStrategy strategy;
	public ComputerPlayer() {
		strategy = new accumulateHandBasedStrategy();
	}
	public void setStrategy(PlayingStrategy strategy) {
		this.strategy = strategy;
	}
	
	//  컴퓨터 플레이어는 필요없는 메소드
	@Override 
	public void setHand(HandType hand) {}
	
	@Override 
	public HandType nextHand(boolean isUserAttack){
		strategy.setLastUserHand(getOpponentResult());
		super.setHand(strategy.computeNextHand(isUserAttack));
		return super.nextHand(isUserAttack);
	}
}