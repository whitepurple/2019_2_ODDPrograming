/**
 * 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습
 * @version 2019년도 2학기 
 * GameModel.java: 
 * 묵찌바 게임에 필요한 데이터와 게임논리 구현
 * @author 김상진
 */
public class GameModel {
	private Player computer = new ComputerPlayer();
	private Player user = new UserPlayer();
	private boolean playingMookJiBa = false;
	private boolean isUserAttack = false;
	{
		user.setHand(HandType.MOOK);
	}
	
	// 새 게임을 할 때마다 객체를 생성하는 대신 사용 (상태 초기화)
	public void init() {
		user.setHand(HandType.MOOK);
		playingMookJiBa = false;
		isUserAttack = false;
		computer.setOpponentResult(null);
	}
	
	// 기본 Getter
	public HandType getUserHand() {
		return user.getHand();
	}
	public boolean isUserAttack() {
		return isUserAttack;
	}
	public boolean playingMookJiBa() {
		return playingMookJiBa;
	}
	
	public void setUserHand(HandType userHand) {
		user.setHand(userHand);
	}
	
	// 다음 컴퓨터 손을 계산함
	public HandType getComputerHand() {
		return computer.nextHand(isUserAttack);
	}
	
	// @return 승자가 있으면 true 없으면 false
	public GameResult playMookJiBa() {
		if(user.getHand().equals(computer.getHand())) {
			playingMookJiBa = false;
			return isUserAttack? GameResult.USERWIN: GameResult.COMPUTERWIN;
		}
		else {
			isUserAttack = computer.getHand().winValueOf().equals(user.getHand());
			computer.setOpponentResult(user.getHand());
			return GameResult.DRAW;
		}
	}
	// @return 승자가 있으면 true 없으면 false
	public GameResult playGawiBawiBo() {
		if(user.getHand()==computer.getHand()) return GameResult.DRAW;
		isUserAttack = computer.getHand().winValueOf().equals(user.getHand());
		playingMookJiBa = true;
		return isUserAttack?GameResult.USERWIN:GameResult.COMPUTERWIN;
	}
	
}
