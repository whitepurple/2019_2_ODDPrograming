import java.util.concurrent.ThreadLocalRandom;

public class LastHandBasedStrategy implements PlayingStrategy {
	private HandType lastUserHand = null;
	public void setLastUserHand(HandType hand) {
		lastUserHand = hand;
	}
	
	public HandType computeNextHand(boolean isUserAttack) {
		System.out.println(lastUserHand);
		if(lastUserHand == null) {
			return HandType.valueOf(ThreadLocalRandom.current().nextInt(3));
		}
		else {
			HandType nextHand = HandType.valueOf((lastUserHand.ordinal() 
								//1, 1, 2, 2, 3의 값으로 20%확률로 같은 값
								+ ThreadLocalRandom.current().nextInt(5)/2 + 1) % 3 );
			return isUserAttack? nextHand.winValueOf() : nextHand;
		}
	}
	

}
