import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습
 * @version 2019년도 2학기 
 * 전략 패턴
 * MookJiBaGame.java: 묵찌바 메인 클래스
 * @author 김상진
 */
public class MookJiBaGame extends Application{
	private GameModel gameModel = new GameModel();
	private GameView gameView = new GameView(gameModel);
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		primaryStage.setTitle("묵찌바 게임");
		primaryStage.setScene(new Scene(gameView));
		primaryStage.show();
		gameView.init();
	}

	public static void main(String[] args) {
		Application.launch(args);
	}
}
