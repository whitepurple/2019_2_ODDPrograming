/**
 * 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습
 * @version 2019년도 2학기 
 * 전략 패턴
 * Player.java: 추상 클래스
 * @author 김상진
 */
public abstract class Player {
	private HandType opponentResult;
	private HandType hand;

	public void setOpponentResult(HandType hand) {
		opponentResult = hand;
	}
	public HandType getOpponentResult() {
		return opponentResult;
	}
	public void setHand(HandType hand) { 
		this.hand = hand; 
	}
	public HandType getHand() {
		return hand;
	}
	public HandType nextHand(boolean isUserAttack) {
		return hand;
	}
}
