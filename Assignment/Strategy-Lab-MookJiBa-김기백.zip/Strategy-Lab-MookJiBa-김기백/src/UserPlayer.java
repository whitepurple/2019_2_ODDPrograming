/**
 * 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습
 * @version 2019년도 2학기 
 * 전략 패턴
 * UserPlayer.java
 * 이 응용에서 꼭 필요한 클래스는 아님
 * @author 김상진
 */
public class UserPlayer extends Player {
}
