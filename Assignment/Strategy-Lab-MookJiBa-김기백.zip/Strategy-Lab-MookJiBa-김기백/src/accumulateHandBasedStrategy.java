import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.IntStream;

public class accumulateHandBasedStrategy implements PlayingStrategy {

	//상대방의 누적 손 타입 횟수를 기록할 배열
	private int[] accumulateHandType = {5,5,5,0};
	
	@Override
	public void setLastUserHand(HandType hand) {
		//hand가 null타입일 때 예외처리
		Optional<HandType> optHandType = Optional.ofNullable(hand);
		accumulateHandType[optHandType.map(HandType::ordinal).orElse(3)]++;
		accumulateHandType[3]=0; //안 쓰는 곳의 횟수를 올리고 초기화
	}
	
	@Override
	public HandType computeNextHand(boolean isUserAttack) {
		// 누적 횟수의 비율을 기준으로 다음의 손을 계산
		// 상대가 많이 낸 만큼 많이 낼 것이라고 판단
		int value = ThreadLocalRandom.current().nextInt(IntStream.of(accumulateHandType).filter(n -> n>4).sum())+1;
		//value가 작을 수록 묵, 찌, 빠 순
		int result=0;
		while(result<2){	//어느 인덱스에 속하는지 탐색
			value -=  accumulateHandType[result];
			if(value<=0) break;
			result++;
		}
		return isUserAttack? HandType.valueOf(result).winValueOf():HandType.valueOf(result);
	}
}
