import java.util.ArrayList;

/**
 * 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습
 * 2019년도 2학기
 * @author 김상진 
 * 탬플릿 메소드 패턴
 * BlackJackGame.java
 * 블랙잭 게임
 */
public class BlackJackGame extends CardGame {
	private static int NUMBEROFCARDSPERPLAYER = 2;
	@Override
	protected void dealCards() {
		for(int i=0; i<numberOfPlayers; i++) {
			ArrayList<Card> userCard = new ArrayList<>();
			for(int j=0; j<NUMBEROFCARDSPERPLAYER; j++)
				userCard.add(remainingDeck.poll());
			userCards.add(userCard);
		}
	}
}
