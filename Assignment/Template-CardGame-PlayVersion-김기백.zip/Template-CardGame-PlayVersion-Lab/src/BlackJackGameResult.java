/**
 * 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습
 * 2019년도 2학기
 * @author 김상진 
 * 탬플릿 메소드 패턴
 * BlackJackGameResult.java
 * 블랙잭 게임 결과
 */
public enum BlackJackGameResult {
	DRAW, USERWIN, USERLOST
}
