import java.util.ArrayList;

/**
 * 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습
 * 2019년도 2학기 
 * @author 김상진  
 * 탬플릿 메소드 패턴
 * BlackJackPlayerHand.java
 * 블랙잭 게임에서 각 플레이어의 패 정보 유지
 */
public class BlackJackPlayerHand {
	private ArrayList<Card> cards;
	private int score = 0;
	private boolean isBlackJack = false;
	public BlackJackPlayerHand(ArrayList<Card> cards) {
		this.cards = cards;
		score = computeScore();
	}
	public void init() {
		cards.clear();
		score = 0;
		isBlackJack = false;
	}
	public ArrayList<Card> getCards(){
		return cards;
	}
	public void addCard(Card card) {
		cards.add(card);
		score = computeScore();
	}
	public int getScore() {
		return score;
	}
	public boolean isBlackJack() {
		return isBlackJack;
	}
	private int computeScore() {
		isBlackJack=false;
		int result = 0;
		int aceCount = 0;
		for(Card c : cards) {
			int num = c.getNumber();
			if (num==1) ++aceCount;
			result+=((num>10)?10:num);
		}
		if(aceCount>0) {
			for(int i=0;i<aceCount;i++) {
				if(result+10<=21)
					result+=10;
			}
		}
		if (result==21) isBlackJack=true;
		return result;
	}
	public static BlackJackGameResult determineResult(
		BlackJackPlayerHand userHand, BlackJackPlayerHand dealerHand) {
		boolean isUserBusted = userHand.getScore()>21;
		boolean isDealerBusted = dealerHand.getScore()>21; 
		if(isUserBusted&&isDealerBusted)
			return BlackJackGameResult.DRAW;
		else if (userHand.getScore()!=dealerHand.getScore()) {
			if(isUserBusted) return BlackJackGameResult.USERLOST;
			if(isDealerBusted) return BlackJackGameResult.USERWIN;
			if ((21-userHand.getScore())>(21-dealerHand.getScore()))
				return BlackJackGameResult.USERLOST;
			else 
				return BlackJackGameResult.USERWIN;
		}
		else {
			if(userHand.isBlackJack())
				return BlackJackGameResult.USERLOST;
			else
				return BlackJackGameResult.DRAW;
		}
	}
}
