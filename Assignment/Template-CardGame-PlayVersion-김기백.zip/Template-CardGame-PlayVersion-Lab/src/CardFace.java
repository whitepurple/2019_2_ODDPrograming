/**
 * 한국기술교육대학교 컴퓨터공학부 객체지향개발론및실습
 * 2019년도 2학기
 * 탬플릿 메소드 패턴
 * CardFace.java
 * 카드의 모양을 나타내는 열거형
 * @author 김상진 
 */
public enum CardFace {
	CLUBS, HEARTS, DIAMONDS, SPADES 
}
